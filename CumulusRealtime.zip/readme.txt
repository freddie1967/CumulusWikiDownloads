Cumulus Realtime v1.0.0.5
-------------------------

Edit the file CumulusRealtime.xml to set the options. You will 
need to change the "realtimeURL" and "sitename" at the very 
least - unless you actually want to display my data!

The "realtimeURL" should be the URL of your realtime.txt file.

The "label" items can be changed, this is mainly provided so 
that you can translate them into another language. You can't 
currently edit the units, or the compass points.

You can change the start and end colours of the background 
gradient by editing the following items:

    <backgroundtopcolour>B4B4B4</backgroundtopcolour>
    <backgroundbottomcolour>000000</backgroundbottomcolour>

The colours are specified as RRGGBB in hex, so B4B4B4 is a light
grey, and 000000 is black. You can set the top and bottom colours 
to the same value if you don't want a gradient.

You can also set the font colour for most of the text:
    
    <fontcolour>FFFFFF</fontcolour>

The default FFFFFF is white.

Be very careful not to break the XML structure!

Upload all of the files (except the readme.txt and changes.txt)
to a directory on your web server, and link to the 
CumulusRealtime.html page from somewhere on your site. You can 
create your own page to host the application if you wish, and it 
should also be possible to embed the application in an existing
page - you should be able to work out what to do by studying the
supplied html.

Currently, only the rain gauges will re-scale, but I'll work on 
getting the others to do it too.

Note that if you sometimes access your web site from a URL with 
and without "www" on the front, then the default Silverlight
cross-domain access restrictions will stop it working. See this
thread in the forum for what you need to do:
http://sandaysoft.com/forum/viewtopic.php?f=14&t=1495
The same applies, of course, if you are running Cumulus
Realtime on one domain but your realtime.txt file is held on
another domain.

Some web servers will need to have the file extension XAP configured. 
If you only see a blank grey page when you browse to the gauges page, 
yours may be one. In which case configure the server's MIME 
Extensions to include:

.xap application/x-silverlight-app

(see your web server's documentation)

Please report any problems and make suggestions for enhancements
in the forum.


Steve Loft
September 2009

Copyright notice
----------------
"Cumulus Realtime" is Copyright Sandaysoft 2009. No copying or
redistribution permitted.
Contains components which are the Copyright of Telerik. These
components may not be used for any purpose other than as
part of Cumulus Realtime.
